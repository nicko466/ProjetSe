/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import jus.poc.prodcons.v.TestProdCons;

/**
 *
 * @author nicko2
 */
public class Affichage extends JFrame{
    
  private JPanel panProducteur;
  private JRadioButton[] rbProducteur; 
  private JPanel panConsommateur;
  private JRadioButton[] rbConsommateur;
  private ButtonGroup group = new ButtonGroup();
  private JPanel panTampon;
  private int nbProd;
  private int nbCons;
    
  public Affichage(int nbProd,int nbCons){
    this.setTitle("Producteur/Consommateur");
    this.setSize(400, 500);
    this.setLocationRelativeTo(null);
    this.setLayout(new BorderLayout());
    //initialisation du nombre de Producteur && du nombre de Consommateur
    this.nbProd = nbProd;
    this.nbCons = nbCons;
    //Initialisation des panels
    panTampon = new JPanel();
    panConsommateur= new JPanel();
    panProducteur = new JPanel();
    initJPanelConsommateur(nbCons);
    initJPanelProducteur(nbProd);
    initJPanelTampon(12);
    //Placement des différents JPanel
    this.add(panProducteur,BorderLayout.WEST);
    this.add(panConsommateur,BorderLayout.EAST);
    this.add(panTampon,BorderLayout.CENTER);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);             
    this.setVisible(true);
  }
  
  
  public void initJPanelProducteur(int nbCons){
      System.out.println(""+nbCons);
      JLabel labelProd = new JLabel("Producteur");
      panProducteur.setLayout(new BoxLayout(panProducteur, BoxLayout.Y_AXIS));
      panProducteur.add(labelProd);
      for(int i =0 ; i<nbCons;i++){
          rbProducteur[i] = new JRadioButton("Producteur : "+i);
          panProducteur.add(rbProducteur[i]);
      }
      
  }
  
  public void initJPanelConsommateur(int nbProd){
      JLabel labelCons = new JLabel("Consommateur");
      panConsommateur.add(labelCons);
      for(int i =0 ; i<nbProd;i++){
          rbConsommateur[i] = new JRadioButton("Consommateur : "+i);
          panConsommateur.add(rbConsommateur[i]);
      }
  }
    
  public void initJPanelTampon(int taille){
      JLabel labelProd = new JLabel("Tampon");
      panTampon.add(labelProd);
  }
  
}
