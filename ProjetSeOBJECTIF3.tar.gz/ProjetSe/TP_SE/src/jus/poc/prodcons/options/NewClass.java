/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jus.poc.prodcons.options;

/**
 *
 * @author nicko2
 */
public class NewClass {
     public static void main(String[] args){
        
    }
}
